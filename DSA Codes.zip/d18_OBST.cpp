#include <iostream>
#include <climits>
using namespace std;

void input(int a[], int n, int start) {
    if (start != 0) {
        a[0] = 0;
    }
    for (int i = start; i < n; i++) {
        cin >> a[i];
    }
}

void obst() {
    int n;
    cout << "Enter no. of keys: ";
    cin >> n;

    int l = n + 1;
    int keys[l], p[l], q[l], C[l][l] = {0}, W[l][l] = {0}, r[l][l] = {0};

    cout << "Use space between keys and enter only " << n << " keys!\nEnter keys: ";
    input(keys, l, 1);

    cout << "\nEnter Success Probability: ";
    input(p, l, 1);

    cout << "\nEnter Unsuccessful Probability: ";
    input(q, l, 0);

    for (int i = 0; i < l; i++) {
        W[i][i] = q[i];
        C[i][i] = 0;
    }

    for (int m = 1; m < l; m++) { // m = chain length
        for (int i = 0; i < l - m; i++) {
            int j = i + m;
            W[i][j] = W[i][j - 1] + p[j] + q[j];
            C[i][j] = INT_MAX;

            for (int k = i + 1; k <= j; k++) { // Evaluate roots
                int cost = C[i][k - 1] + C[k][j] + W[i][j];
                if (cost < C[i][j]) {
                    C[i][j] = cost;
                    r[i][j] = k;
                }
            }
        }
    }

    // Print the matrices in the specified format
    cout << "\nMatrix Outputs:\n";
    for (int k = 0; k < l; k++) { // Row index corresponds to diagonal offset
        // Print Weights (W)
        for (int i = 0; i < l - k; i++) {
            int j = i + k; // Determine the column
            cout << "W[" << i << "][" << j << "] = " << W[i][j] << " |\t";
        }
        cout << endl;

        // Print Costs (C)
        for (int i = 0; i < l - k; i++) {
            int j = i + k; // Determine the column
            cout << "C[" << i << "][" << j << "] = " << C[i][j] << " |\t";
        }
        cout << endl;

        // Print Roots (r)
        for (int i = 0; i < l - k; i++) {
            int j = i + k; // Determine the column
            cout << "r[" << i << "][" << j << "] = " << r[i][j] << " |\t";
        }
        cout << endl;

        // Add a blank line after each set of W, C, r rows
        cout << endl;
    }
}

int main() {
    obst();
    return 0;
}
