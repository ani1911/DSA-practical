#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;

class student{
public:
	struct stud{
		int roll;
		char name[10],add[10],div;
	};
	stud rec;
	
	void create();
	void display();
	int search();
	void deletion();
};

void student::create(){
	ofstream fout;
	fout.open("RECORDS.dat", ios::out | ios::binary);
	char cond;
	do{
		cout<<"\n\tENTER THE ROLL NUMBER OF STUDENT: ";
		cin>>rec.roll;
		cout<<"\n\tENTER THE NAME OF STUDENT: ";
		cin>>rec.name;
		cout<<"\n\tENTER THE DIVISON OF STUDENT: ";
		cin>>rec.div;
		cout<<"\n\tENTER THE ADDRESS OF STUDENT: ";
		cin>>rec.add;
		
		fout.write((char*)&rec,sizeof(stud))<<flush;
		
		cout<<"\nDO YOU WANT TO CONTINUE: (Y?N)"<<endl;
		cin>>cond;
	}while(cond=='Y' || cond=='y');
	fout.close();
}

void student::display(){
	ifstream fin;
	fin.open("RECORDS.dat", ios::in | ios::binary);
	fin.seekg(0);
	int i=0;
	cout<<"\n\tCONTENTS OF FILE: "<<endl;
	cout<<"\n\tROLL"<<"\tNAME"<<"\tDIV"<<"\tADDRESS"<<endl;
	while(fin.read((char*)&rec,sizeof(stud))){
		cout<<"\t"<<rec.roll<<"\t"<<rec.name<<"\t"<<rec.div<<"\t"<<rec.add<<endl;
	}
	fin.close();
}

int student::search(){
	int r;
	
	ifstream fin;
	fin.open("RECORDS.dat", ios::in | ios::binary);
	fin.seekg(0);
	cout<<"\n\tENTER THE ROLL NUMBER TO BE SEARCHED: ";
	cin>>r;
	while(fin.read((char*)&rec,sizeof(stud))){
	
		if(rec.roll==r){
			cout<<"\n\tRECORD FOUND!!"<<endl;
			cout<<"\n\tROLL"<<"\tNAME"<<"\tDIV"<<"\tADDRESS"<<endl;
			cout<<"\t"<<rec.roll<<"\t"<<rec.name<<"\t"<<rec.div<<"\t"<<rec.add<<endl;
			return 1;
		}
	}
	fin.close();
	return -1;
}

void student::deletion(){
	int pos;
	pos = search();
	fstream f;
	f.open("RECORDS.dat",ios::in|ios::out|ios::binary);
	f.seekg(0,ios::beg);
	if(pos==0)
	{
		cout<<"\nRECORD NOT FOUND !!";
		return;
	}
	int offset=pos*sizeof(stud);
	f.seekp(offset);
	rec.roll=-1;
	strcpy(rec.name,"NULL");
	rec.div='N';
	strcpy(rec.add,"NULL");
	f.write((char*)&rec,sizeof(stud));
	f.seekg(0);
	f.close();
	cout<<"\n\tRECORD DELETED SUCCESSFULLY !!!";
}

int main(){
	student s;
	int ch,k;
	do{
		cout<<"\n\t ********** MENU **********"<<endl;
		cout<<"\n\t1.CREATE\n\t2.DISPLAY\n\t3.SEARCH\n\t4.DELETE\n\t5.EXIT\n\tENTER YOUR CHOICE: ";
		cin>>ch;
		
		switch(ch){
			case 1:
				s.create();
				break;
			case 2:
				s.display();
				break;
			case 3:
				k=s.search();
				if(k==-1){
					cout<<"\n\tRecord NOT Found"<<endl;
				}
				break;
			case 4:
				
				break;
			case 5:
				cout<<"EXITING............:)"<<endl;
				break;
			default:
				cout<<"\nINVALID CHOICE!!!!"<<endl;
				break;
		}
	}while(ch!=5);
	return 0;
}
