/*You have a business with several offices; you want to lease phone lines to connect them
up with each other; and the phone company charges different amounts of money to
connect different pairs of cities. You want a set of lines that connects all your offices
with a minimum total cost. Solve the problem by suggesting appropriate data structures*/

//prims algorithm

#include <iostream>
#include <limits> // For numeric_limits

using namespace std;

class PrimAlgorithm {
    static const int MAX = 100; // Maximum number of offices
    int graph[MAX][MAX];
    bool inMST[MAX];
    int key[MAX];
    int parent[MAX];
    int vertices;

public:
    PrimAlgorithm(int v) : vertices(v) {
        for (int i = 0; i < MAX; ++i) {
            inMST[i] = false;
            key[i] = numeric_limits<int>::max(); // Use numeric_limits for INT_MAX
            parent[i] = -1;
        }

        for (int i = 0; i < MAX; ++i) {
            for (int j = 0; j < MAX; ++j) {
                graph[i][j] = 0;
            }
        }
    }

    void addEdge(int u, int v, int weight) {
        graph[u][v] = weight;
        graph[v][u] = weight; // Undirected graph
    }

    void display() {
        cout << "\nAdjacency Matrix of the Graph:\n";
        for (int i = 0; i < vertices; ++i) {
            for (int j = 0; j < vertices; ++j) {
                cout << graph[i][j] << " ";
            }
            cout << endl;
        }
    }

    void primMST() {
        key[0] = 0; // Start from the first office (vertex 0)
        parent[0] = -1;

        for (int count = 0; count < vertices - 1; ++count) {
            int minKey = numeric_limits<int>::max(); // Use numeric_limits for INT_MAX
            int minIndex = -1;

            for (int v = 0; v < vertices; ++v) {
                if (!inMST[v] && key[v] < minKey) {
                    minKey = key[v];
                    minIndex = v;
                }
            }

            if (minIndex == -1) {
                cout << "Error: No more vertices to process. The graph might be disconnected." << endl;
                return;
            }

            int u = minIndex;
            inMST[u] = true;

            for (int v = 0; v < vertices; ++v) {
                if (graph[u][v] != 0 && !inMST[v] && graph[u][v] < key[v]) {
                    parent[v] = u;
                    key[v] = graph[u][v];
                }
            }
        }

        printMST();
    }

    void printMST() {
        int mstCost = 0;
        cout << "Edges in the Minimum Spanning Tree:" << endl;
        for (int i = 1; i < vertices; ++i) {
            cout << parent[i] << " - " << i << " : " << graph[i][parent[i]] << endl;
            mstCost += graph[i][parent[i]];
        }
        cout << "Minimum total cost to connect all offices: " << mstCost << endl;
    }
};

int main() {
    int offices;
    cout << "Enter the number of offices (vertices): ";
    cin >> offices;

    if (offices <= 0 || offices > 100) {
        cout << "Error: Number of offices must be between 1 and 100." << endl;
        return 1;
    }

    PrimAlgorithm primAlgo(offices);
    int choice;

    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Add an edge\n";
        cout << "2. Display the graph\n";
        cout << "3. Run Prim's Algorithm\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int u, v, weight;
                cout << "Enter the edge (source, destination, weight): ";
                cin >> u >> v >> weight;
                if (u >= 0 && u < offices && v >= 0 && v < offices) {
                    primAlgo.addEdge(u, v, weight);
                } else {
                    cout << "Invalid vertices! Please try again.\n";
                }
                break;
            }
            case 2: {
                primAlgo.display();
                break;
            }
            case 3: {
                primAlgo.primMST();
                break;
            }
            case 4: {
                cout << "Exiting program.\n";
                return 0;
            }
            default: {
                cout << "Invalid choice! Please try again.\n";
                break;
            }
        }
    }
}

