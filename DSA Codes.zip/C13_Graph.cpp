/*C-13 : Represent a given graph using adjacency matrix/list to perform DFS and using adjacency
list to perform BFS. Use the map of the area around the college as the graph. Identify the
prominent land marks as nodes and perform DFS and BFS on that.*/

#include <iostream>
using namespace std;
#define size 50

class Stack{
	int top;
	int nodes[size];
	
	public:
	Stack(){
		top = -1;
	}
	
	int Isempty(){
		if (top == -1)
			return 1;
		return 0;
	}
	
	int Isfull(){
		if (top >= size-1)
			return 1;
		return 0;
	}
	
	void push(int x){
		nodes[++top] = x;
	}
	
	int pop(){
		int x = nodes[top--];
		return x;
	}
};

class Graph{
	
	public:
	Graph(int nodes_count, int graph[10][10]){
		for (int i=0; i<nodes_count; i++){
			for (int j=0; j<nodes_count; j++)
				graph[i][j] = 0;
		}
	}
	
	void graph_matrix(int graph[10][10], int vertex[10]){
		int edges_count, m, n2;
		
		static int n = 0;
		
		cout << "Enter no. of edges in graph : ";
		cin >> edges_count;
		
		for (int i=0; i<edges_count; i++){
			cout << "Enter nodes associated with edge " << i+1 << " : ";
			cin >> m >> n2;
			
			graph[m][n2] = 1;
			
			for (int j=0; j<n+2; j++){
				if (vertex[j] != m)
					vertex[n++] = m;
				if (vertex[j] != n2)
					vertex[n++] = n2;
			}		
		}
	}
	
	void DFS(int graph[][10], int vertex[10], int nodes_count){
		Stack s;
		int visited[nodes_count];
		for (int i=0; i<nodes_count; i++)
			visited[i] = 0;
		s.push(vertex[0]);
		
		while(s.Isempty()){
			int v1 = s.pop();
			if (visited[v1] == 0){
				cout << v1 << endl;
				visited[v1] = 1;
				
				for (int i=0; i<nodes_count; i++){
					if ((graph[v1][i] == 1) & (visited[graph[v1][i]] == 0))
						s.push(graph[v1][i]);
				}
			}
		}
	}
};

int main(){
	
	int n,g[10][10];
	cout << "Enter no. of nodes in Graph : ";
	cin >> n;
	
	Graph gr(n, g);
	
	//int graph[n][n];
	int vertex[10];
	
	gr.graph_matrix(g, vertex);
	gr.DFS(g, vertex, n);
	
	return 0;
}


