'''Consider telephone book database of N clients. Make use of a hash table implementation
to quickly look up client‘s telephone number. Make use of two collision handling
techniques and compare them using number of comparisons required to find a set of
telephone numbers.'''

table_size = int(input("Enter table size : "))
hash_table = [-1 for i in range(table_size)]

def display():
	print("|","INDEX","|", "KEYS","|")
	for i,j in enumerate(hash_table):
		print("|",i,"\t|", j,"  |")
		
display()

def hash_function():
	key = int(input("\nEnter telephone no. to store : "))
	index = key % table_size
	
	if -1 not in hash_table:
		print("Hash Table full !!")
		return
	
	elif (hash_table[index] == -1):
		hash_table[index] = key
		print("Telephone no. store success !!")
		display()
	
	else:
		if -1 not in hash_table[index+1:table_size]:
			index = -1
		
		for i in range(index+1, table_size):
			if (hash_table[i] == -1):
				hash_table[i] = key
				print("Telephone no. store success !!")
				display()
				break
			
'''n = int(input("\nEnter no. of clints : "))	
for i in range(n):
	hash_function()'''
	
def double_hash_function():
	key = int(input("\nEnter telephone no. to store : "))
	h1 = key % table_size
	
	if -1 not in hash_table:
		print("Hash Table full !!")
		return
	
	elif (hash_table[h1] == -1):
		hash_table[h1] = key
		print("Telephone no. store success !!")
		display()
	
	else:
		h2 = 7 - (key % 7)
		for i in range(table_size):
			index = (h1 + i*h2) % table_size
			
			if (hash_table[index] == -1):
				hash_table[index] = key
				print("Telephone no. store success !!")
				display()
				break
		
n = int(input("\nEnter no. of clints : "))	
for i in range(n):
	double_hash_function()

def double_hash_searching():
	key = int(input("\nEnter telephone no. to search : "))
	h1 = key % table_size
	
	if (hash_table[h1] == key):
		print("Telephone no. found at :",h1)
	
	else:
		h2 = 7 - (key % 7)
		for i in range(table_size):
			index = (h1 + i*h2) % table_size
			
			if (hash_table[index] == key):
				print("Telephone no. found at :",index)
				break
		else:
			print("Element not found")
	
	

double_hash_searching()

def quadratic_hashing():
	key = int(input("\nEnter telephone no. to store : "))
	index = key % table_size
	
	if -1 not in hash_table:
		print("Hash Table full !!")
		return
	
	elif (hash_table[index] == -1):
		hash_table[index] = key
		print("Telephone no. store success !!")
		display()
	
	else:
		for i in range(table_size):
			if (hash_table[i] == -1):
				index = (key + i**2) % table_size
				hash_table[index] = key
				print("Telephone no. store success !!")
				display()
				break



'''n = int(input("\nEnter no. of clints : "))	
for i in range(n):
	quadratic_hashing()'''







