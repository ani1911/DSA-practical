#include <iostream>
using namespace std;

class node
{
	string label;
	node *root, *child[50];
	int ch_count;
	
	public:
	node()
	{
		root = NULL;
		for (int i = 0; i < 50; ++i)
            child[i] = NULL;
	}
	
	node* create();
	void display(node*);
};

node* node::create()
{
	int i,j,k;
	
	root = new node;
	cout<<"Enter book name : ";
	cin >> root->label;
	cout << "Enter no. of chapters : ";
	cin >> root->ch_count;
	
	for (i=0; i< root->ch_count; i++)
	{
		root->child[i] = new node;
		cout<<"Enter Chapter name : ";
		cin >> root->child[i]->label;
		cout << "Enter no. of sections : ";
		cin >> root->child[i]->ch_count;
		
		for (j=0; j< root->child[i]->ch_count; j++)
		{
			root->child[i]->child[j] = new node;
			cout<<"Enter Section name : ";
			cin >> root->child[i]->child[j]->label;
			cout << "Enter no. of sub-sections : ";
			cin >> root->child[i]->child[j]->ch_count;
		
		
			for (k=0; k < root->child[i]->child[j]->ch_count; k++)
			{
				root->child[i]->child[j]->child[k] = new node;
				cout<<"Enter Sub-section name : ";
				cin >> root->child[i]->child[j]->child[k]->label;
			}
		}
	}
	return root;
}

void node::display(node *root)
{
	int i,j,k;
	
	if (root != NULL)
	{	
		cout<<"\nBook name : "<< root->label << endl;
		
		for (i=0; i< root->ch_count; i++)
		{
			cout<<"\nChapter name : "<<root->child[i]->label << endl;
			
			for (j=0; j< root->child[i]->ch_count; j++)
			{
				cout<<"\nSection name : "<< root->child[i]->child[j]->label<< endl;
				
				for (k=0; k< root->child[i]->child[j]->ch_count; k++)
				{
					cout<<"\nSub-section name : "<< root->child[i]->child[j]->child[k]->label << endl;
				}
			}
		}
	}
	else
		cout << "\nCreate book first !!\n";
}

int main()
{
	node n1;
	node *root;
	int ch;
		
	do
	{
		cout<<"\n-----------MENU-------------\n";
		cout<<"\n1.CREATE"
			<<"\n2.DISPLAY"
			<<"\n3.EXIT"
			<<"\n\nEnter choice : ";
		cin>>ch;
	 	switch(ch)
	 	{
	 		case 1 : {
	 				root=n1.create();
	 				break;
	 				}
	 		case 2 : {
	 				n1.display(root);
	 				break;
	 				}
	 		case 3 : {
	 				cout<<"\nTHAAAANKUUUUUUU!!!!!🤬️\n";
	 				exit (0);
					}
	
	 	}
	}while(ch<4);
	return 0;
}

