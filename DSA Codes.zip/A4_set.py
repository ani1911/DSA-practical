'''To create ADT that implement the "set" concept.
a. Add (newElement) -Place a value into the set
b. Remove (element) Remove the value
c. Contains (element) Return true if element is in collection
d. Size () Return number of values in collection Iterator () Return an iterator used to loop
over collection
e. Intersection of two sets
f. Union of two sets
g. Difference between two sets
h. Subset'''

class Set:
	'''def __init__(self,count):
		self.count = count'''
	
	def add(self, s):
		a = int(input("Enter a number to add in set : "))
		if a not in s:
			s.append(a)
		
	def remove1(self, s):
		a = int(input("Enter a number to remove from set : "))
		if a in set1:
			s.remove(a)
		
	def contains(self, s):
		a = int(input("Enter a number to check in set : "))
		return a in s
		
	def size1(self, s1):
		count = 0
		itr = iter(s1)
		for i in itr: count+=1
		print("Size of set is :", count)
	
	def intersection(self, s1, s2):
		intersec = [i for i in s1 if i in s2]
		print("Intersection is : ", end="")
		self.display(intersec)

	def union(self, s1, s2):
		union = list(dict.fromkeys(s1 + [j for j in s2 if j not in s1]))
		print("Union is : ", end="")
		self.display(union)
				
	def display(self, s):
		print("{", end=""); print(", ".join(map(str, s[:-1])), end=", "); print(s[-1], "}", sep="")
		
	def difference(self, s1, s2):
		difference = [i for i in s1 if i not in s2]
		print("Difference is : ", end="")
		self.display(difference)
				
				
	def subset(self, s1, s2):
		subset = []				
				
	def __iter__(self):
		return iter(self.set1)


def menu():
	s = Set()
	set1_len = int(input("Enter no. of elements in set 1 : "))
	set1 = [int(input("Enter set elemets : ")) for i in range(set1_len)]
	
	set2_len = int(input("\nEnter no. of elements in set 2 : "))
	set2 = [int(input("Enter set elemets : ")) for i in range(set2_len)]
	
	while True:
		choice = int(input('''\nThese are available operations that can be performed :-
1. Add (newElement) 
2. Remove (element) 
3. Contains (element) Returns true if element is in collection
4. Size 
5. Intersection of two sets
6. Union of two sets
7. Difference between two sets
8. Subset
9. Display
0. Exit
\nEnter your choice : '''))

		if choice == 1:
			subchoice = int(input('''\nAvailable sets :-
1. Set 1
2. Set 2
\nChoose preferred set : '''))
		
			if subchoice == 1:
				s.add(set1)
			else:
				s.add(set2)
			
		elif choice == 2:
			subchoice = int(input('''\nAvailable sets :-
1. Set 1
2. Set 2
\nChoose preferred set : '''))
		
			if subchoice == 1:
				s.remove1(set1)
			else:
				s.remove1(set2)
	
		elif choice == 3:
			subchoice = int(input('''\nAvailable sets :-
1. Set 1
2. Set 2
\nChoose preferred set : '''))
		
			if subchoice == 1:
				print(s.contains(set1))
			else:
				print(s.contains(set2))
				
		elif choice == 4:
			subchoice = int(input('''\nAvailable sets :-
1. Set 1
2. Set 2
\nChoose preferred set : '''))
		
			if subchoice == 1:
				s.size1(set1)
			else:
				s.size1(set2)
				
		elif choice == 5:
			s.intersection(set1, set2)	
				
		elif choice == 6:
			s.union(set1, set2)	
		
		elif choice == 7:
			s.difference(set1, set2)	
				
		elif choice == 8:
			s.subset(set1, set2)
		
		elif choice == 9:
			subchoice = int(input('''\nAvailable sets :-
1. Set 1
2. Set 2
\nChoose preferred set : '''))
		
			if subchoice == 1:
				s.display(set1)
			else:
				s.display(set2)
		
		elif choice == 0:
			print("\nThank You !!\nBye bye !!")
			break
		
		else:
			print("\nInvalid Input !!\nTry Again")
			continue
		
		
		repeat_lst = ['Y', "YES", '1']
		repeat = input("\nDo you want to perform another operation ?\n(Y=1,N=0) : ")
		
		if repeat.capitalize() in repeat_lst:
			continue
		else:
			print("\nThank You !!\nBye bye !!")
			break
	
		
menu()
		
		
		
				
				
