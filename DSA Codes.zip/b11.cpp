#include <iostream>
#include <string.h>
using namespace std;

class node{
	char key[20], m[20];
	node *left, *right;
	
	public:
	node* create();
	node* insert(node*, node*);
	node* delete_node(node*, char[]);
	node* search(node*, char[]);
	void display(node*);
	node* findMin(node*);
};

node* node::create(){
	node *root;
	int ch = 0;
	
	do{
		node *p = new node;
		cout<<"\nEnter key : ";
		cin >> p->key;
		cout << "Enter meaning : ";
		cin >> p->m;
		
		if (root == NULL)
			root = p;
		else
			insert(root, p);
			
		cout << "\nDo you wish to add more ?(Y=1/N=0) : ";
		cin >> ch;
	}while(ch == 1);
	
	return root;
}

node* node::insert(node *root, node *p){

	if (strcmp(root->key, p->key)){
	
		if (root->left == NULL)
			root->left = p;
		else
			insert(root->left, p);
	}
	else{
	
		if (root->right == NULL)
			root->right = p;
		else
			insert(root->right, p);
	}
	
	return root;
}

void node::display(node *root){
	if (root != NULL)
	{
		cout << "Key : "<< root->key;
		cout << "\tMeaning : " << root->m << endl;
		display(root->left);
		display(root->right);
	}
	
}

node* node::delete_node(node* root, char a[]){
	if(root == NULL)
		return NULL;
	else{
		cout << strcmp(a, root->key) << endl;
		cout << strcmp(a, root->key) << endl;
		
		if (strcmp(a, root->key) < 0)
			root->left = delete_node(root->left, a);
		
		else if (strcmp(a, root->key) > 0)
			root->right = delete_node(root->right, a);
			
		else{
			if (root->left == NULL){
				node *temp = root->right;
				delete root;
				return temp;
			}
			else if (root->right == NULL){
				node *temp = root->left;
				delete root;
				return temp;
			}
			else{
				node *successor = findMin(root->right);
				strcpy(root->key, successor->key);
				strcpy(root->m, successor->m);
				root->right = delete_node(root->right, successor->key);
			}
		}
	}
	return root;
}

node* node::findMin(node *node){
	while (node->left != NULL)
		node = node->left;
	return node;
}

int main(){
	node n1;
	node *root;
	char a[20];
	
	root = n1.create();
	n1.display(root);
	
	cout<<"Enter key to delete : ";
	cin >> a;
	root = n1.delete_node(root, a);
	n1.display(root);
	
	return 0;
}









