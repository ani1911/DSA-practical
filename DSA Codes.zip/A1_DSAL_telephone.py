table_size = 11
hash_table =[-1 for i in range(table_size)]
	
print(hash_table)

def hash_function():
	key=int(input("\nENTER TELEPHONE NO. TO STORE:"))
	index = key % table_size
	
	if -1 not in hash_table:
		print("\nHASH TABLE IS FULL!!")
		return
	
	elif (hash_table[index] == -1):
		hash_table[index] = key
		print(hash_table,"\nTELEPHONE NO. STORED SUCCESSFULLY!!")
		
	else:
		if -1 not in hash_table[index+1:table_size]:
			index = -1
			
		for i in range(index+1,table_size):
			if (hash_table[i] == -1):
				hash_table[i] = key
				print("\n",hash_table,"\nTELEPHONE NO. STORED SUCCESSFULLY!!")
				break
				
n=int(input("\nENTER NO.OF CLIENTS :"))				
for i in range(n):				
	hash_function()
	
def double_hash_function():
	key=int(input("\nENTER TELEPHONE NO. TO STORE:"))
	h1 = key % table_size
	
	if -1 not in hash_table:
		print("\nHASH TABLE IS FULL!!")
		return
		
	elif (hash_table[h1] == -1):
		hash_table[h1] = key
		print(hash_table,"\nTELEPHONE NO. STORED SUCCESSFULLY!!")
		
	else:
		h2 = 7 - (key%7)
		for i in range(table_size):
			index = (h1+i*h2) % table_size
	
			if (hash_table[index] == -1):
				hash_table[index] = key 
				print(hash_table,"\nTELEPHONE NO. STORED SUCCESSFULLY!!")
				break

n=int(input("\nENTER NO.OF CLIENTS :"))				
for i in range(n):				
	double_hash_function()				

def double_hash_function_searching():
	key=int(input("\nENTER TELEPHONE NO. TO SEARCH:"))
	h1 = key % table_size
	
	if -1 not in hash_table:
		print("\nHASH TABLE IS FULL!!")
		return
		
	elif (hash_table[h1] == key):
		print("\nTELEPHONE NO. FOUND SUCCESSFULLY AT ",h1,"INDEX !!!")
		
	else:
		h2 = 7 - (key%7)
		for i in range(table_size):
			index = (h1+i*h2) % table_size
	
			if (hash_table[index] == key):
				print("\nTELEPHONE NO. FOUND SUCCESSFULLY AT ",index,"INDEX !!!")
				break

				
double_hash_function_searching()				


	
