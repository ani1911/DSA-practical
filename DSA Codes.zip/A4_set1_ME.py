"""To create ADT that implement the "set" concept. a. Add (new Element) -Place a value into the set , b. Remove (element) Remove the value c. Contains (element) Return true if element is in collection, d. Size () Return number of values in collection Iterator () Return an iterator used to loop over collection, e. Intersection of two sets , f. Union of two sets, g. Difference between two sets, h. Subset"""


class Set:
    def __init__(self, elements=None):
        if elements is None:
            self.set = set()
        else:
            self.set = set(elements)

    def add(self, element):
        self.set.add(element)

    def remove(self, element):
        if element in self.set:
            self.set.remove(element)
        else:
            print("ELEMENT NOT FOUND !!")

    def contains(self, element):
        return element in self.set

    def size(self):
        return len(self.set)

    def __str__(self):
        return f"{self.set}"

    def intersection(self, otherset):
        return Set(self.set & otherset.set)

    def union(self, otherset):
        return Set(self.set | otherset.set)

    def difference(self, otherset):
        return Set(self.set - otherset.set)

    def subset(self, otherset):
        return self.set.issubset(otherset.set)

    def __iter__(self):
        return iter(self.set)

# Example usage:
my_set1 = Set()
my_set2 = Set()
flag = 1
while flag == 1:
    print("\n------------MENU--------------")
    print("WHAT ACTIONS WOULD YOU LIKE TO PERFORM???")
    print("1. ADD ELEMENTS IN SET 1")
    print("2. ADD ELEMENTS IN SET 2")
    print("3. REMOVE ELEMENTS FROM SET 1")
    print("4. REMOVE ELEMENTS FROM SET 2")
    print("5. DISPLAY ELEMENTS FROM SETS")
    print("6. FIND INTERSECTION")
    print("7. FIND UNION")
    print("8. FIND DIFFERENCE")
    print("9. CHECK SUBSET")
    print("10. EXIT")
    ch = int(input("ENTER YOUR CHOICE: "))
    if ch == 1:
        n = int(input("ENTER THE ELEMENTS OF SET 1: "))
        my_set1.add(n)
    elif ch == 2:
        n = int(input("ENTER THE ELEMENTS OF SET 2: "))
        my_set2.add(n)
    elif ch == 3:
        m = int(input("ENTER THE ELEMENTS OF SET 1 TO REMOVE: "))
        my_set1.remove(m)
    elif ch == 4:
        m = int(input("ENTER THE ELEMENTS OF SET 2 TO REMOVE: "))
        my_set2.remove(m)
    elif ch == 5:
        print("Set 1 =", my_set1)
        print("Set 2 =", my_set2)
    elif ch == 6:
        interset = my_set1.intersection(my_set2)
        print("INTERSECTION =", interset)
    elif ch == 7:
        unionset = my_set1.union(my_set2)
        print("UNION =", unionset)
    elif ch == 8:
        diffset = my_set1.difference(my_set2)
        print("DIFFERENCE =", diffset)
    elif ch == 9:
        is_subset = my_set1.subset(my_set2)
        print(f"SET 1 IS {'a' if is_subset else 'not a'} SUBSET OF SET 2")
    elif ch == 10:
        flag = 0
        print("THANK YOU!")
    else:
        print("INVALID CHOICE! ENTER VALID CHOICE!")

